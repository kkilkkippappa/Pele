﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// 판정 스크립트!
public class Judge : MonoBehaviour
{
    // JudgeLine
    GameObject judgeLine;
    Transform judgeLineTransform;

    // 점수에 해당하는 변수들..
    public Text scoreText;
    int score = 0;
    // Start is called before the first frame update
    void Start()
    {
        judgeLine = GameObject.Find("judgeLine");   // unity 상의 judgeLine 오브젝트와 연결.
        judgeLineTransform = judgeLine.transform;
        setScoreText();
    }

    // Update is called once per frame
    void Update()
    {
        
    }



    public void setScoreText()
    {
        scoreText.text = "Score : " + score;
    }
}
