﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEditor.Build.Reporting;
using UnityEngine;

public class BmsLoad : MonoBehaviour
{
    public Bms bms;
    public Bar barData;

    private void Awake()
    {
        bms = GameObject.Find("Bms").GetComponent<Bms>();
        barData = GameObject.Find("Bar").GetComponent<Bar>();
    }

    private void Start()
    {
        
    }

    public void readBMS(string fileName)   // 인자값으로 해당 파일명을 
    {
        string[] lineData = File.ReadAllLines(Application.dataPath + "/Music/BMS_Files/" + fileName + ".bms");
        Debug.Log("readBms : " + lineData);

        // 파일 한 줄씩 읽어들어 데이터를 파싱한다.
        foreach(string line in lineData)
        {
            if (line.StartsWith("#"))
            {
                string[] data = line.Split(' ');

                // 데이터 섹션이 아니면서 헤더 데이터가 없는 경우에는 건너 뜀.
                if (data[0].IndexOf(":") == -1 && data.Length == 1)
                {
                    continue;
                }

                // 헤더 부분 파싱(곡 정보)
                if (data[0].Equals("#TITLE")) { 
                    bms.setTitle(data[1]);
                }
                else if (data[0].Equals("#ARTIST")) bms.setArtist(data[1]);
                else if (data[0].Equals("#BPM")) bms.setBpm(float.Parse(data[1]));
                else if (data[0].Equals("#PLAYER"))
                {

                }
                else if (data[0].Equals("#GENRE"))
                {

                }
                else if (data[0].Equals("#PLAYLEVEL"))
                {

                }
                else if (data[0].Equals("#RANK"))
                {

                }
                else if (data[0].Equals("#SUBTITLE"))
                {

                }
                else if (data[0].Equals("#SUBARTIST"))
                {

                }
                else if (data[0].Equals("#DIFFICULTY"))
                {

                }
                else if (data[0].Equals("#TOTAL"))
                {

                }
                else if (data[0].Equals("#LNTYPE"))
                {

                }
                else if (data[0].IndexOf(":") != -1)
                {
                    // 위의 경우에 모두 해당하지 않을 경우, 데이터 섹션

                    // 어느 마디인지 구성.
                    int bar = 0;
                    Int32.TryParse(data[0].Trim().Substring(1, 3), out bar);

                    // 어느 라인에서 칠 지...  1@ : @라인에서 노트가 내려오고 유저가 쳐야하는 노트.
                    int channel = 0;
                    Int32.TryParse(data[0].Trim().Substring(4, 2), out channel);

                    // bar(마디) 내에 표시되는 노트
                    string noteInfo = data[0].Trim().Substring(7);


                    // 노트 마디 데이터 저장!
                    barData.bar = bar;
                    barData.channel = channel;

                    // 이하 2줄이 문제!
                    barData.noteData = getNotedata_InBarData(bar, channel, noteInfo);

                    bms.sumBarCount();   // bar 총개수 증가!
                    bms.addBar(barData);// BmsLoad 스크립트에서 파싱한 bar 정보를 bsm 스크립트의 noteList에 저장!
                }   

            } // if # 구문 끝
        }// foreach 문 끝
    }

    // barData 안에 들어있는 note 데이터들 구하는 함수

    // #00011:0000000000000101
    // noteInfo : 0000000000000101, bar : 000, channel : 11

    public List<Dictionary<int, float>> getNotedata_InBarData(int bar, int channel, string noteInfo) 
    {
        // 마디 안에 노트가 있다. 노트 : 라인 위치, 몇박에 노트가 있는지 중요하다.
        List<Dictionary<int, float>> noteObj_inBar = new List<Dictionary<int, float>>();   

        int countBeatofBar = 0;   // 이 bar 안에 비트가 몇 개 있나 세는 변수.
        float barCount = (float)bar;   // BMS 파일상 bar(마디)가 총 몇 개인지 알리는 변수.
        noteInfo = noteInfo.Trim(); // 혹시 모를 공백 제거.

        // barBeatCount 구하기
        if(noteInfo.Length != 0)
        {
            // noteInfo : 00, a2 등 2개의 문자가 비트 하나 취급되기 때문이다.
            countBeatofBar = noteInfo.Length / 2;    
        }

        float secondPerBar = 60.0f / bms.bpm * 4.0f;
        float preBarSecond = barCount * secondPerBar;   // 전의 bar의 시간.

        float beatCount = 0;    // 마디 안에 비트가 몇개 있나 세는 변수
        // list(노트 시간, 노트 라인, 노트 비트정보) 담는 거 만듬.

        // while문 : 한 마디 안에 들어있는 노트 추출
        while (true)
        {
            Dictionary<int, float> noteData = new Dictionary<int, float>();

            // noteMaid : d3, a1 등을 나타냄.
            int noteMadi = 0;
            Int32.TryParse(noteInfo.Substring(0, 2), out noteMadi);

            // 노트가 올 타이밍(시간)구하는 문구
            float time = 0;
            if(noteMadi != 0)   // noteMadi == 0 이라면 노트가 없기 때문에 시간 X
            {
                time = preBarSecond + (secondPerBar / countBeatofBar * beatCount);
            }
            
            noteData.Add(noteMadi, time);
            noteObj_inBar.Add(noteData);    // dic 리스트 noteObj_inBar에 noteData 데이터 삽입....
            bms.totalPlayTime = time;

            Debug.Log($"{bms.noteCount}번째 note 정보 : 마디;{noteMadi}, 시간;{time}");
            if(noteInfo.Length > 2)
            {
                noteInfo = noteInfo.Substring(2);
            }
            else
            {
                break;
            }
            beatCount++;
        }

        // bms 파일에 있는 총노트수 구하기
        foreach(Dictionary<int, float> noteData in noteObj_inBar)
        {
            foreach(float i in noteData.Values)
            {
                if (i != 0)
                    bms.sumNoteCount();
            }
        }
        return noteObj_inBar;
    }

    void debugBms()
    {
        Debug.Log($"bms : \ntitle: {bms.title}, artist: {bms.artist}\nbpm: {bms.bpm}, totalNote: {bms.noteCount}");
    }
}
