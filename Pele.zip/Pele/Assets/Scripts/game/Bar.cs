﻿using System.Collections;
using System.Collections.Generic;
using System.Net.Http.Headers;
using Unity.Profiling.LowLevel.Unsafe;
using UnityEngine;

public class Bar : MonoBehaviour
{
    // Bar : bms 파일에서 각 마디의 channel, bar 정보를 뽑아서 저장. 
    // Note는 Noteobj.cs 스크립트에서 
    public int bar { get; set; }   // 몇 마디째인지 표시.
    public int channel { get; set; }   // 값 1 : 유저/시스템이 처리해야하는 노트, 값2 : 내려오는 라인 번호.

    // int : 마디, ex)01, d2  float : 시간
    public List<Dictionary<int, float>> noteData { get; set; }   // 노트 정보를 갖고 있는 dictionary 데이터

    private void Reset()
    {
        bar = 0;
        channel = 0;
        noteData = new List<Dictionary<int, float>>();
    }
}