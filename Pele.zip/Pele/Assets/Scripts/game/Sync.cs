﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 음악의 재생 및 싱크를 담당하는 코드.
// 11-09 현재 코드가 너무 난잡해짐. 이거 정리해야함.
public class Sync : MonoBehaviour
{
    // 유니티에서 음악 재생 시 필요한 변수? 가 2개 있다.
    // AudioSource : 음악을 재생시킬 라디오라고 생각하면 편함.
    // AudioClip : 라디오에 넣을 카세트라고 생각하자.

    public AudioSource musicPlayer;    // 오디오를 재생시키는 컴포넌트.
    public AudioClip musicClip;   // 재생시킬 소리.

    // 음악 시작 딜레이 주는 변수
    // 게임이 시작되자마자 노트가 곧바로 떨어지면 안되기 때문에 딜레이를 준다.
    public float musicDelaySecond = 2f;

    // 유니티 시간 측정 변수
    float gameTimer = 0f;
    bool isMusicStart = false;


    // 음악 실행이 안됨.
    private void Awake()
    {
        musicPlayer = GetComponent<AudioSource>();
    }
    void Start()
    {
        Debug.Log($"delaytime : {musicDelaySecond}");
        // GetComponent<AudioClip>() 넣으면 음악 재생 불가!
    }

    // Update is called once per frame
    void Update()
    {
        gameTimer = gameTimer + Time.deltaTime; // 컴퓨터 FPS와 상관없음!
        setMusicStart_Delay();
    }

    public void musicStart(AudioSource audioSource, AudioClip audioClip)
    {
        audioSource.Stop();
        audioSource.clip = audioClip;   // 음악 파일을 카세트에 넣어주기!
        audioSource.loop = false;
        audioSource.Play();
    }

    void setMusicStart_Delay()
    {
        if (gameTimer >= musicDelaySecond && isMusicStart == false)
        {
            isMusicStart = true;    // 음악이 재생되었으니 true로 값을 줌.
            musicStart(musicPlayer, musicClip);
        }
    }

   /* void setMusicStart_Delay()
    {
        if(isMusicStart == false)
        {
            musicStart(musicPlayer, musicClip);
        }
    }

    IEnumerator musicStart()
    {
        yield return new WaitForSeconds(musicDelaySecond);  // musicDelaySecond 초 동안 쉬고

        // 음악 시작
        setMusicStart_Delay();
    }*/
}
