﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Note_obj : MonoBehaviour
{
    // Note_obj.cs  : 노트 데이터들을 담은 파일. 뿐만 아니라 노트 시작지점. 
    // Note_obj 는 sprite.

    // userLine, 노트가 나타날 시간 등을 표시. 
    public int noteLine { get; set; }
    public string noteInfo { get; set; }
    public float noteStartTime { get; set; }
    public float speed { get; set; }    // 노트배속

    float judgeY = 0f;
    float destroyY = 0f;

    public bool isStart = false;

    
    // 노트 생성위치와 삭제 위치 차이 구하기
    GameObject noteFolder;  // note(여러 화살표)들은 Notes 오브젝트에 들어가있음.
    float noteMove = 0f;    // 얼마큼 노트가 이동해야하는지 나타내는 변수.
    float noteFolderY = 0f;

    GameObject destroyLine;
    GameObject judgeLine;
    public GameObject gameObject = null;

    private void Awake()
    {
        destroyLine = GameObject.Find("destroyLine");  // destroy line y 좌표를 위해 가져옴.
        destroyY = destroyLine.transform.position.y;
        judgeLine = GameObject.Find("judgeLine");
        judgeY = judgeLine.transform.position.y;

        // noteMove 구하기!
        noteFolder = GameObject.Find("Notes");
        noteFolderY = noteFolder.transform.position.y;

        noteMove = destroyY - noteFolderY;
        //Debug.Log("destroyY : " + destroyY);
        //Debug.Log("noteFolderY : " + noteFolderY + "\nnoteMove : " + noteMove);
    }

    private void Start()
    {
        //Debug.LogError("note_obj.cs 에서 가져온 object : " + gameObject.name);
    }

    private void Update()
    {
        if(isStart == true)
        {
            StartCoroutine(moveNote());
        }
    }
    IEnumerator moveNote()
    {
        // 현재 노트 위치가 삭제지점위치(destroy line의 y값) 보다 작다면 삭제!
        if (transform.position.y > destroyY)
        {
            transform.Translate(Vector3.up * speed * Time.smoothDeltaTime);
        }
        else
        {
            Destroy(gameObject);
        }
        yield return null;
    }

    public void setPosition(float x = 0, float y = 0, float z = 0)
    {
        try
        {
            transform.localPosition = new Vector3(x, y, z);  // nullException 에러 발생.
        }
        catch(NullReferenceException e)
        {
            Debug.LogError("Note_obj.cs  setPosition 에러 발생!");
        }
    }
    public Vector3 getPosition()
    {
        return transform.position;
    }
}
