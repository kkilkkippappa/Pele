﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bms : MonoBehaviour
{
    // Bms : bms 파일 하나에 대한 정보를 담은 코드.
    // 나중에 bsm file을 파싱할 때 여기에다가 정보를 저장한다.
    public string title;
    public string artist;
    public float bpm;
    public List<Bar> barList;    // 노트 데이터들을 저장할 리스트
    public int barCount;    // 한곡당 마디 수
    public int noteCount;  // 한곡당 총 노트 수 
    public float totalPlayTime { get; set; }    // 총 재생시간.

    private void Reset()    // start() 전에 불러옴. 초기화를 위해 실행
    {
        title = "";
        artist = "";
        bpm = 0;
        barList = new List<Bar>();   // 노트 데이터 리스트.
        barCount = 0;
        noteCount = 0;
        totalPlayTime = 0;
    }

    public void setTitle(string title) { this.title = title; }
    public string getTitle() { return title; }
    public void setArtist(string artist) { this.artist = artist; }
    public string getArtist() { return artist; }
    public void setNoteList(List<Bar> bar) { this.barList = bar; }
    public List<Bar> getNoteList() { return barList; }
    public void setBpm(float bpm) { this.bpm = bpm; Debug.Log($"bms 파일 bms : {bpm}"); }
    public float getBpm() { return bpm; }

    // node add
    public void addBar(Bar bar)
    {
        barList.Add(bar);
    }

    // totalNoteCount 증가 함수
    public void sumNoteCount()
    {
        noteCount++;
    }

    public void sumBarCount()
    {
        barCount++;
    }
}
