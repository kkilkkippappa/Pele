﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class puaseClick : MonoBehaviour
{
    public GameObject PopUp;
    public Button againButton;
    public Button endButton;
    // Start is called before the first frame update
    void Start()
    {
        PopUp.SetActive(false);
    }
    public void PauseButton_click()
    {
        PopUp.SetActive(true);
    }

    //dialogScripts
    public void again_Awake()
    {
        againButton.onClick.RemoveAllListeners();
        againButton.onClick.AddListener(again_ButtonClicked);
    }
    public void end_Awake()
    {
        endButton.onClick.RemoveAllListeners();
        endButton.onClick.AddListener(end_ButtonClicked);
    }
    void again_ButtonClicked()
    {
        Debug.Log("게임 이어서 하기");
        PopUp.SetActive(false);
    }
    void end_ButtonClicked()
    {
        Debug.Log("게임 종료");
        SceneManager.LoadScene("GameoverScene");
    }
}
