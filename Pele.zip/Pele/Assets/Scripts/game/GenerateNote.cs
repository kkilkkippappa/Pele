﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateNote : MonoBehaviour
{
    public Sync sync;
    public Bms bms;
    public BmsLoad bmsLoad;

    float secondPerBar = 0f; // Bar 당 시간(초).
    float secondPerBeat = 0f; // Beat 당 시간(초).
    float samplePerBar = 0f; // Bar 당 PCM 샘플.
    float samplePerBeat = 0f; // Beat 당 PCM 샘플.
    float beatPerBar = 0f;  // Bar 당 beat 시간. 이걸 구하자.

    public List<Note_obj> noteLine1;
    public List<Note_obj> noteLine2;
    public List<Note_obj> noteLine3;
    public List<Note_obj> noteLine4;
    public List<Note_obj> noteLine5;

    // 각 라인마다 노트가 얼마나 생성되었는지 체크하는 변수
    int noteLine1_count = 0;
    int noteLine2_count = 0;
    int noteLine3_count = 0;
    int noteLine4_count = 0;
    int noteLine5_count = 0;

    // Instantiate(obj, obj.transform.position, obj.transform.rotation)
    //Instantiate(복제시킬 오브젝트 명, 복제시킬 오브젝트의 위치, 복제시킬 오브젝트의 회전값)

    // 노트 시간 변수
    float noteTime = 0; // 노트 시작 ~ 다음 노트 부르기전까지의 시간 측정.
    float gameTime = 0; // 게임 시작시간 측정. 
    float offsetTime = 0;   // 보정시간 : music start할 때 지연되는 시간까지 계산하는 변수.
    float bpm = 0;

    float nextTime = 0;

    private void Awake()
    {
        sync = GameObject.Find("Sync").GetComponent<Sync>();
        bms = GameObject.Find("Bms").GetComponent<Bms>();
        bmsLoad = GameObject.Find("BmsLoad").GetComponent<BmsLoad>();
    }
    private void Start()
    {
        noteLine1 = new List<Note_obj>();
        noteLine2 = new List<Note_obj>();
        noteLine3 = new List<Note_obj>();
        noteLine4 = new List<Note_obj>();
        noteLine5 = new List<Note_obj>();

        bpm = bms.bpm;

        //offsetTime -= sync.musicDelaySecond;    // 시간 딜레이 보정 완료. 이 줄에서 에러 남.

        //Debug.Log("generaterNote.cs : sync.musicDelaySecond : " + sync.musicDelaySecond);

        beatPerBar = 4;    // 16으로 어림잡아 계산하자.
        secondPerBar = 60.0f / bpm * 4f;    // infinity?                            // Bar 당 시간(초)
        secondPerBeat = 60.0f / bpm * 4f / beatPerBar;   // infinity?           // Beat 당 시간(초).
        samplePerBar = secondPerBar * sync.musicClip.frequency;     // Bar 당 PCM 샘플.
        samplePerBeat = secondPerBeat * sync.musicClip.frequency;

        Debug.Log($"곡의 bpm : {bpm}, secondperbar : {secondPerBar}, secondperbeat : {secondPerBeat}");
    }
    private void Update()
    {
        gameTime += Time.deltaTime; // 게임 시작할 때 시간 측정.
        offsetTime += Time.deltaTime;
    }
    IEnumerator generateNote()
    {
        foreach(Note_obj note in noteLine1)
        {
            Instantiate(note, new Vector3(note.transform.position.x, note.transform.position.y, note.transform.position.z), Quaternion.identity);
        }
        foreach (Note_obj note in noteLine2)
        {
            Instantiate(note, new Vector3(note.transform.position.x, note.transform.position.y, note.transform.position.z), Quaternion.identity);
        }
        foreach (Note_obj note in noteLine3)
        {
            Instantiate(note, new Vector3(note.transform.position.x, note.transform.position.y, note.transform.position.z), Quaternion.identity);
        }
        foreach (Note_obj note in noteLine4)
        {
            Instantiate(note, new Vector3(note.transform.position.x, note.transform.position.y, note.transform.position.z), Quaternion.identity);
        }
        foreach (Note_obj note in noteLine5)
        {
            Instantiate(note, new Vector3(note.transform.position.x, note.transform.position.y, note.transform.position.z), Quaternion.identity);
        }
        yield return new WaitForEndOfFrame();
    }
}
