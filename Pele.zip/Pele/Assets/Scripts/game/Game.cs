﻿using System.Collections;
using System.Collections.Generic;
using Unity.Profiling;
using UnityEngine;
using UnityEngine.UI;

// 여기서 시간에 따라 노트 떨어지는 거 구현
public class Game : MonoBehaviour
{
    // 게임에 필요한 여러 오브젝트들을 불러온다.
    public Bms bms;
    public BmsLoad bmsLoad;
    public Sync sync;

    public string fileName;

    // 노트가 불러와지는 시간과 현재 시간 차이를 비교하기 위해 만든 변수

    // 1 BPM : 1분당 1비트, 1초당 1/60비트! => N bpm ; 1초당 n/60비트
    // barPerSecond 구하는 법 : 1초당 (8*n) / 60 -> 1/32박자 기준! 
    // 1/4 박자 기준 : n/60
    float beatPerSecond; // 초당 beat 횟수

    public List<Note_obj> noteLine1, noteLine2, noteLine3, noteLine4, noteLine5;

    float secondPerBar = 0f; // Bar 당 시간(초).
    float secondPerBeat = 0f; // Beat 당 시간(초).
    float samplePerBar = 0f; // Bar 당 PCM 샘플.
    float samplePerBeat = 0f; // Beat 당 PCM 샘플.
    float beatPerBar = 0f;  // Bar 당 beat 시간. 

    float noteTime = 0f;    // 현재 노트 생성 ~ 다음 노트 생성 전까지의 시간 체크.
    float defaultSpeed = 10;    // 노트 이동값!

    // 각 라인마다 노트가 얼마나 생성되었는지 체크하는 변수
    int noteLine1_count = 0;
    int noteLine2_count = 0;
    int noteLine3_count = 0;
    int noteLine4_count = 0;
    int noteLine5_count = 0;

    Note_obj note;  // 임시로 쓸 변수. 

    private void Reset()
    {
        noteLine1 = new List<Note_obj>();
        noteLine2 = new List<Note_obj>();
        noteLine3 = new List<Note_obj>();
        noteLine4 = new List<Note_obj>();
        noteLine5 = new List<Note_obj>();
    }
    // Start is called before the first frame update
    private void Awake()
    {
        // 다른 스크립트 연결
        bms = GameObject.Find("Bms").GetComponent<Bms>();
        bmsLoad = GameObject.Find("BmsLoad").GetComponent<BmsLoad>();

        bmsLoad.readBMS(fileName);  // bms 파일 읽기.
    }
    void Start()
    {
        // 노트 속도 구현..
        beatPerSecond = bms.bpm / 60;
        secondPerBeat = 60 / bms.bpm;   // secondPerBeat 초 마다 노트가 나타남.
        int noteLine;    // line이 일의 자리수임.

        int cnt = 1;    // 현재 첫번쨰 foreach문이 제대로 돌고 있는지 확인해줄 변수.

        // bms.barList에서 Bar 정보를 가져와 bar.channel에 맞는 note 정보를 noteLine 리스트에 저장! 
        foreach (Bar bar in bms.barList)
        {
            noteLine = bar.channel % 10;
            Debug.Log($"{cnt}번째 bar channel : {bar.channel}, noteLine : {noteLine}");
            // 이 줄에 노트의 시간 구하는 식 적기.
            switch (noteLine)
            {
                // 노트 라인마다 지정되는 위치값 적기. 
                case 1:
                    note = GameObject.Find("arrow_color_1").GetComponent<Note_obj>();
                    note.setPosition((float)-87.4, (float)-24, (float)984);
                    break;
                case 2:
                    note = GameObject.Find("arrow_color_2").GetComponent<Note_obj>();
                    note.setPosition((float)-46.5, (float)-24, (float)984);
                    break;
                case 3:
                    note = GameObject.Find("arrow_color_3").GetComponent<Note_obj>();
                    note.setPosition((float)-4.031168, (float)-24, (float)984);
                    break;
                case 4:
                    note = GameObject.Find("arrow_color_4").GetComponent<Note_obj>();
                    note.setPosition((float)39.1, (float)-24, (float)984);
                    break;
                case 5:
                    note = GameObject.Find("arrow_color_5").GetComponent<Note_obj>();
                    note.setPosition((float)78, (float)-24, (float)984);
                    break;
            }   // switch 구문 끝
            note.noteLine = bar.channel;    // note가 내려오는 라인을 지정해준다.

            // 노트 시간 구하기
            foreach (Dictionary<int, float> noteData in bar.noteData)
            {
                foreach (int key in noteData.Keys)
                {
                    noteTime = noteData[key];   // noteData는 dictionary임.
                    note.noteStartTime = noteTime;
                    note.speed = defaultSpeed;

                    switch (noteLine)   // 설정이 끝난 note를 알맞은 noteLIne에 삽입
                    {
                        case 1:
                            //note.gameObject = GameObject.Find("arrow_color_1");
                            noteLine1.Add(note);
                            noteLine1_count++;
                            break;
                        case 2:
                           // note.gameObject = GameObject.Find("arrow_color_2");
                            noteLine2.Add(note);
                            noteLine2_count++;
                            break;
                        case 3:
                            //note.gameObject = GameObject.Find("arrow_color_3");
                            noteLine3.Add(note);
                            noteLine3_count++;
                            break;
                        case 4:
                            //note.gameObject = GameObject.Find("arrow_color_4");
                            noteLine4.Add(note);
                            noteLine4_count++;
                            break;
                        case 5:
                            //note.gameObject = GameObject.Find("arrow_color_5");
                            noteLine5.Add(note);
                            noteLine5_count++;
                            break;
                    }
                }
            }
            cnt++;
        }
        noteTime += secondPerBeat;

        // Game.cs에서 NoteLine List 만든 걸 GeneratorNote.cs 에 넘김
        GenerateNote generateNote = GameObject.Find("GenerateNote").GetComponent<GenerateNote>();
        generateNote.noteLine1 = noteLine1;
        generateNote.noteLine2 = noteLine2;
        generateNote.noteLine3 = noteLine3;
        generateNote.noteLine4 = noteLine4;
        generateNote.noteLine5 = noteLine5;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

}
