﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainseneChange : MonoBehaviour
{
    public void ChageGamestart()
    {
        SceneManager.LoadScene("Game_musicSelect");
    }
    public void ChageHint()
    {
        SceneManager.LoadScene("Hint");
    }
}
