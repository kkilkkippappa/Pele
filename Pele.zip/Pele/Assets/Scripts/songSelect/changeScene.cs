﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class changeScene : MonoBehaviour
{
    public void goTo_MusicSelectScene()
    {
        SceneManager.LoadScene("MusicSelectScene_1");
    }
    public void goTo_MusicSelectScene_2()
    {
        SceneManager.LoadScene("MusicSelectScene_2");
    }
    public void goTo_PlayScene_1()
    {
        SceneManager.LoadScene("PlayScene_1");
    }public void goTo_PlayScene_2()
    {
        SceneManager.LoadScene("PlayScene_2");
    }
}
