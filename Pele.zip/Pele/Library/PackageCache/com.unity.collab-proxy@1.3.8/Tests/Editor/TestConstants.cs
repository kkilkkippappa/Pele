using System;

namespace Unity.Cloud.Collaborate.Tests
{
    public static class TestConstants
    {
        public const int RENDER_UI_THREAD_DELAY = 1000;
    }
}
